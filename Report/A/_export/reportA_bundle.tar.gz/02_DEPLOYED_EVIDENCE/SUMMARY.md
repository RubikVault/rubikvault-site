# DEPLOYED SUMMARY

generated_at=2026-02-10T19:09:53+01:00

## BASE 71d62877.rubikvault-site.pages.dev

### api_debug-bundle
- default: http_code=200;time_total=0.408511;content_type=application/json; charset=utf-8;size_download=522;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=200;time_total=0.305533;content_type=application/json; charset=utf-8;size_download=522;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=9e8279ce189df3e5e6c72e180b798f28394a9df7e0d2216cee2ab55e71c6d31e
- hash_nocache=fc4e19992321717b767ea1adef58681f7ddef560784575932d4309778df1dc84
- cache_divergence=DIFF
- json_keys: ["data","error","meta","metadata","ok","schema_version"]

### api_debug-matrix
- default: http_code=200;time_total=0.276795;content_type=application/json; charset=utf-8;size_download=409;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=200;time_total=0.427380;content_type=application/json; charset=utf-8;size_download=409;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=e57eb0d73e7b50d7f32e3496cf858362fa9d32dcdab1823b7a50e6344b658960
- hash_nocache=02c476341520035c7fc7c4d8efcc857e1c5722447ddff2ebff05a0a1d8cf9d91
- cache_divergence=DIFF
- json_keys: ["data","error","meta","ok","schemaVersion"]

### api_elliott-scanner
- default: http_code=200;time_total=0.528430;content_type=application/json; charset=utf-8;size_download=17148;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=200;time_total=0.335357;content_type=application/json; charset=utf-8;size_download=17147;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=6a1ea8c50ce6ece2da0b68e30757fba2d4e6b89f6c77e6d7653f9a4b9055f605
- hash_nocache=fba471bb3f100cad7e6bafad4b9a6897d0df235e4c7df1cf85ea3db45b5508ab
- cache_divergence=DIFF
- json_keys: ["data","error","meta","ok","setups"]

### api_fundamentals_ticker_KO
- default: http_code=200;time_total=0.569101;content_type=application/json; charset=utf-8;size_download=1301;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=200;time_total=0.601649;content_type=application/json; charset=utf-8;size_download=1301;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=2079b15be02c1b2dbbbc5c4227d73e13bcf859e301d12937abc5f277d65f5068
- hash_nocache=dfb1eb53d1a591cb9596099dca9e10f2d82a5c1d505a7d5acfd6652095885824
- cache_divergence=DIFF
- json_keys: ["data","error","meta","metadata","ok","schema_version"]

### api_mission-control_summary_debug_1
- default: http_code=200;time_total=2.754087;content_type=application/json; charset=utf-8;size_download=46329;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=200;time_total=2.185423;content_type=application/json; charset=utf-8;size_download=46329;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=610c295dd2e5173f970c60d1ad567fe86fca0f813efaf998bb913aedcef692e9
- hash_nocache=f317608a273e978f218c64fddd9b6f027c2998b0175f1beebaf8d16004aaefbc
- cache_divergence=DIFF
- json_keys: ["data","error","meta","metadata","ok","schema_version"]

### api_scheduler_health
- default: http_code=503;time_total=0.246084;content_type=application/json; charset=utf-8;size_download=455;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=503;time_total=0.230181;content_type=application/json; charset=utf-8;size_download=455;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=e68f4975640e26a79d190621aa85c9c3e5d296853e159520ea295e9581d570e9
- hash_nocache=31dd839220a763003fcc61c646d5ac542d4ea6e982caa4dd43729747cb2e3472
- cache_divergence=DIFF
- json_keys: ["data","error","meta","ok"]

### api_stock_ticker_KO
- default: http_code=200;time_total=1.397911;content_type=application/json; charset=utf-8;size_download=73553;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=200;time_total=0.960540;content_type=application/json; charset=utf-8;size_download=73552;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=6aa2288adf41de834e93a1e0845fedf94c5d54469f9cac704aafcbbee5181a38
- hash_nocache=9d7eb648c791fd3050720c9ded5a81fd74dcbcac6d12d74d79660c9b8c9cc9cd
- cache_divergence=DIFF
- json_keys: ["data","error","meta","metadata","ok","schema_version"]

### api_universe_debug_1
- default: http_code=200;time_total=0.441288;content_type=application/json; charset=utf-8;size_download=1090;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=200;time_total=0.486185;content_type=application/json; charset=utf-8;size_download=1090;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=b81ec6567b3051d9135f6f9253aa98ecf8d8f6bd28ab48656b49087b710db474
- hash_nocache=a969ca332546c6832912acde9203cc0b93e701ff36e797197713a57a5febaa3f
- cache_divergence=DIFF
- json_keys: ["asset_latency_ms","asset_status","build_id","config","data","data_preview","debug","error","failure","kv_backend","kv_latency_ms","kv_status","links","manifest","manifest_ref","meta","metadata","module","module_state","ok","proof_chain","proof_summary","schema_version","served_from","source","suggested_action","timestamp"]

### data_forecast_latest.json
- default: http_code=200;time_total=0.198668;content_type=application/json;size_download=209990;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=200;time_total=0.237501;content_type=application/json;size_download=209990;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=85659fdbe55ba9d4e243de33f9d7f05eba0893f3ccb02ce4397d00baed39b2d1
- hash_nocache=85659fdbe55ba9d4e243de33f9d7f05eba0893f3ccb02ce4397d00baed39b2d1
- cache_divergence=SAME
- json_keys: ["data","feature","generated_at","meta","ok","schema"]

### data_forecast_system_status.json
- default: http_code=200;time_total=0.143484;content_type=application/json;size_download=307;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=200;time_total=0.175096;content_type=application/json;size_download=307;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=4b1cb4227f0abccc5a73b89064aedbe945976f0f6986d1f8d20ec862d2984f3e
- hash_nocache=4b1cb4227f0abccc5a73b89064aedbe945976f0f6986d1f8d20ec862d2984f3e
- cache_divergence=SAME
- json_keys: ["capabilities","circuit_state","generated_at","last_good","last_run","reason","schema","status"]

### data_marketphase_index.json
- default: http_code=404;time_total=0.206929;content_type=text/html; charset=utf-8;size_download=86;content_type_json=FAIL;html_prefix=FAIL;jq_parse=FAIL;body_non_empty=PASS;
- nocache: http_code=404;time_total=0.175621;content_type=text/html; charset=utf-8;size_download=86;content_type_json=FAIL;html_prefix=FAIL;jq_parse=FAIL;body_non_empty=PASS;
- hash_default=6608707d0b7f6926396c335466f83cf725feadc94c2fad15e5adb5a7380040fe
- hash_nocache=6608707d0b7f6926396c335466f83cf725feadc94c2fad15e5adb5a7380040fe
- cache_divergence=SAME
- json_keys: JSON_PARSE_FAILED

### data_snapshots_market-prices_latest.json
- default: http_code=200;time_total=0.279480;content_type=application/json;size_download=607501;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=200;time_total=0.279762;content_type=application/json;size_download=607501;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=2f6e9eaf9de92bf415d215ce9d0a202c474b9f59e76323e15c77e8a6e3cb2cb3
- hash_nocache=2f6e9eaf9de92bf415d215ce9d0a202c474b9f59e76323e15c77e8a6e3cb2cb3
- cache_divergence=SAME
- json_keys: ["data","error","meta","metadata","schema_version"]

### data_snapshots_stock-analysis.json
- default: http_code=200;time_total=0.524295;content_type=application/json;size_download=1219577;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=200;time_total=0.352664;content_type=application/json;size_download=1219577;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=567dc372579a350e0c273920375dacc17eb1dc7fe86bfbf635bf8f11e74170c0
- hash_nocache=567dc372579a350e0c273920375dacc17eb1dc7fe86bfbf635bf8f11e74170c0
- cache_divergence=SAME
- json_keys: ["A","AAPL","ABBV","ABNB","ABT","ACGL","ACN","ADBE","ADI","ADM","ADP","ADSK","AEE","AEP","AES","AFL","AIG","AIZ","AJG","AKAM","ALB","ALGN","ALL","ALLE","AMAT","AMCR","AMD","AME","AMGN","AMP","AMT","AMZN","ANET","AON","AOS","APA","APD","APH","APO","APP","APTV","ARE","ARM","ASML","ATO","AVB","AVGO","AVY","AWK","AXON","AXP","AZN","AZO","BA","BAC","BALL","BAX","BBY","BDX","BEN","BF.B","BG","BIIB","BK","BKNG","BKR","BLDR","BLK","BMY","BR","BRK.B","BRO","BSX","BX","BXP","C","CAG","CAH","CARR","CAT","CB","CBOE","CBRE","CCEP","CCI","CCL","CDNS","CDW","CEG","CF","CFG","CHD","CHRW","CHTR","CI","CINF","CL","CLX","CMCSA","CME","CMG","CMI","CMS","CNC","CNP","COF","COIN","COO","COP","COR","COST","CPAY","CPB","CPRT","CPT","CRL","CRM","CRWD","CSCO","CSGP","CSX","CTAS","CTRA","CTSH","CTVA","CVS","CVX","CZR","D","DAL","DASH","DAY","DD","DDOG","DE","DECK","DELL","DG","DGX","DHI","DHR","DIS","DLR","DLTR","DOC","DOV","DOW","DPZ","DRI","DTE","DUK","DVA","DVN","DXCM","EA","EBAY","ECL","ED","EFX","EG","EIX","EL","ELV","EMN","EMR","ENPH","EOG","EPAM","EQIX","EQR","EQT","ERIE","ES","ESS","ETN","ETR","EVRG","EW","EXC","EXE","EXPD","EXPE","EXR","F","FANG","FAST","FCX","FDS","FDX","FE","FFIV","FI","FICO","FIS","FITB","FOX","FOXA","FRT","FSLR","FTNT","FTV","GD","GDDY","GE","GEHC","GEN","GEV","GFS","GILD","GIS","GL","GLW","GM","GNRC","GOOG","GOOGL","GPC","GPN","GRMN","GS","GWW","HAL","HAS","HBAN","HCA","HD","HIG","HII","HLT","HOLX","HON","HPE","HPQ","HRL","HSIC","HST","HSY","HUBB","HUM","HWM","IBM","ICE","IDXX","IEX","IFF","INCY","INTC","INTU","INVH","IP","IPG","IQV","IR","IRM","ISRG","IT","ITW","IVZ","J","JBHT","JBL","JCI","JKHY","JNJ","JPM","K","KDP","KEY","KEYS","KHC","KIM","KKR","KLAC","KMB","KMI","KMX","KO","KR","KVUE","L","LDOS","LEN","LH","LHX","LII","LIN","LKQ","LLY","LMT","LNT","LOW","LRCX","LULU","LUV","LVS","LW","LYB","LYV","MA","MAA","MAR","MAS","MCD","MCHP","MCK","MCO","MDLZ","MDT","MELI","MET","META","MGM","MHK","MKC","MKTX","MLM","MMC","MMM","MNST","MO","MOH","MOS","MPC","MPWR","MRK","MRNA","MRVL","MS","MSCI","MSFT","MSI","MSTR","MTB","MTCH","MTD","MU","NCLH","NDAQ","NDSN","NEE","NEM","NFLX","NI","NKE","NOC","NOW","NRG","NSC","NTAP","NTRS","NUE","NVDA","NVR","NWS","NWSA","NXPI","O","ODFL","OKE","OMC","ON","ORCL","ORLY","OTIS","OXY","PANW","PAYC","PAYX","PCAR","PCG","PDD","PEG","PEP","PFE","PFG","PG","PGR","PH","PHM","PKG","PLD","PLTR","PM","PNC","PNR","PNW","PODD","POOL","PPG","PPL","PRU","PSA","PSKY","PSX","PTC","PWR","PYPL","QCOM","RCL","REG","REGN","RF","RJF","RL","RMD","ROK","ROL","ROP","ROST","RSG","RTX","RVTY","SBAC","SBUX","SCHW","SHOP","SHW","SJM","SLB","SMCI","SNA","SNPS","SO","SOLV","SPG","SPGI","SRE","STE","STLD","STT","STX","STZ","SW","SWK","SWKS","SYF","SYK","SYY","T","TAP","TDG","TDY","TEAM","TECH","TEL","TER","TFC","TGT","TJX","TKO","TMO","TMUS","TPL","TPR","TRGP","TRI","TRMB","TROW","TRV","TSCO","TSLA","TSN","TT","TTD","TTWO","TXN","TXT","TYL","UAL","UBER","UDR","UHS","ULTA","UNH","UNP","UPS","URI","USB","V","VICI","VLO","VLTO","VMC","VRSK","VRSN","VRTX","VST","VTR","VTRS","VZ","WAB","WAT","WBA","WBD","WDAY","WDC","WEC","WELL","WFC","WM","WMB","WMT","WRB","WSM","WST","WTW","WY","WYNN","XEL","XOM","XYL","XYZ","YUM","ZBH","ZBRA","ZS","ZTS","_meta","_rankings"]

### data_universe_all.json
- default: http_code=200;time_total=0.243014;content_type=application/json;size_download=30769;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=200;time_total=0.198333;content_type=application/json;size_download=30769;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=2672904ce07ec8bf26adcc87e654788c34f1aef79cca22a09d5cf14d3831252f
- hash_nocache=2672904ce07ec8bf26adcc87e654788c34f1aef79cca22a09d5cf14d3831252f
- cache_divergence=SAME
- json_keys: [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,266,267,268,269,270,271,272,273,274,275,276,277,278,279,280,281,282,283,284,285,286,287,288,289,290,291,292,293,294,295,296,297,298,299,300,301,302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,317,318,319,320,321,322,323,324,325,326,327,328,329,330,331,332,333,334,335,336,337,338,339,340,341,342,343,344,345,346,347,348,349,350,351,352,353,354,355,356,357,358,359,360,361,362,363,364,365,366,367,368,369,370,371,372,373,374,375,376,377,378,379,380,381,382,383,384,385,386,387,388,389,390,391,392,393,394,395,396,397,398,399,400,401,402,403,404,405,406,407,408,409,410,411,412,413,414,415,416,417,418,419,420,421,422,423,424,425,426,427,428,429,430,431,432,433,434,435,436,437,438,439,440,441,442,443,444,445,446,447,448,449,450,451,452,453,454,455,456,457,458,459,460,461,462,463,464,465,466,467,468,469,470,471,472,473,474,475,476,477,478,479,480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,495,496,497,498,499,500,501,502,503,504,505,506,507,508,509,510,511,512,513,514,515,516]

### html_
- html_probe_meta: http_code=200;time_total=0.182404;content_type=text/html; charset=utf-8;size_download=72811;html_markers=PASS;error_marker=NONE;

### html_elliott.html
- html_probe_meta: http_code=308;time_total=0.157159;content_type=;size_download=0;html_markers=FAIL;error_marker=NONE;

### html_forecast.html
- html_probe_meta: http_code=308;time_total=0.130780;content_type=;size_download=0;html_markers=FAIL;error_marker=NONE;

### html_scientific.html
- html_probe_meta: http_code=308;time_total=0.131721;content_type=;size_download=0;html_markers=FAIL;error_marker=NONE;

## BASE rubikvault.com

### api_debug-bundle
- default: http_code=200;time_total=0.331404;content_type=application/json; charset=utf-8;size_download=522;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=200;time_total=0.480044;content_type=application/json; charset=utf-8;size_download=522;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=6bfffb3d3ce2f5dddd4b0774bf32eb0aa51bea2bc807b4b865e312766444a483
- hash_nocache=5a6ac74031f6e9b897a0a44ef68b7641315400b424e1a29da4ef50aceda5d548
- cache_divergence=DIFF
- json_keys: ["data","error","meta","metadata","ok","schema_version"]

### api_debug-matrix
- default: http_code=200;time_total=0.443630;content_type=application/json; charset=utf-8;size_download=409;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=200;time_total=0.522042;content_type=application/json; charset=utf-8;size_download=409;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=6f5e0cf298b54a7d30d1602a0d7d88e2b0b4f1f73f06dcc212674e4ffb3210fa
- hash_nocache=6b902eb1ddfc3258ecc3a12e16477af5f2c517c188c8d23182453661e99fb81c
- cache_divergence=DIFF
- json_keys: ["data","error","meta","ok","schemaVersion"]

### api_elliott-scanner
- default: http_code=200;time_total=0.398440;content_type=application/json; charset=utf-8;size_download=87902;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=200;time_total=0.397031;content_type=application/json; charset=utf-8;size_download=87902;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=c6ff9ebb8af73937eb42003df77d983d6adfe571c7a0cee91a1e824e5bf7fd03
- hash_nocache=ec1231dba7bd88507e398d73ddf286497b3ca1832755771400947878aa1c4eb8
- cache_divergence=DIFF
- json_keys: ["data","error","meta","ok","setups"]

### api_fundamentals_ticker_KO
- default: http_code=200;time_total=0.542570;content_type=application/json; charset=utf-8;size_download=1301;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=200;time_total=0.599420;content_type=application/json; charset=utf-8;size_download=1301;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=d9e9f98c2f52fb2dd9e85593683a3381450e50c752e08323160b447425addcae
- hash_nocache=2ff46c6c6788c94570577ad84beea41fab24174b68149d0ee4116d277e5e5712
- cache_divergence=DIFF
- json_keys: ["data","error","meta","metadata","ok","schema_version"]

### api_mission-control_summary_debug_1
- default: http_code=200;time_total=2.818190;content_type=application/json; charset=utf-8;size_download=126453;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=200;time_total=3.764929;content_type=application/json; charset=utf-8;size_download=126453;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=d7e46ffc9989d8b4eb50db7b6acf6fc843b0cd7a4fc5db60fd8d6f8c3173b6e8
- hash_nocache=97e398c0df2c61ab657e41d6e8ebd88737c545d30c4752e79be05cbf8c21fe1e
- cache_divergence=DIFF
- json_keys: ["data","error","meta","metadata","ok","schema_version"]

### api_scheduler_health
- default: http_code=503;time_total=0.234909;content_type=application/json; charset=utf-8;size_download=455;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=503;time_total=0.288032;content_type=application/json; charset=utf-8;size_download=455;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=d5ead1933e4553d0caba1fe1471654a86dd4ea9c79cd6d3a3777de027b349789
- hash_nocache=e219ce6104a37f6b1afcd247c63e4a5544ed3715e0d50b3f8f9950627f5b509c
- cache_divergence=DIFF
- json_keys: ["data","error","meta","ok"]

### api_stock_ticker_KO
- default: http_code=200;time_total=1.110367;content_type=application/json; charset=utf-8;size_download=73552;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=200;time_total=0.944327;content_type=application/json; charset=utf-8;size_download=73552;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=0423aa4accaf3b734a59959d4202083045b46567f12076c20b6bbebbac50bb90
- hash_nocache=df78b474988c191fbc12a48e23b4e5849f22319690f3fbf33fa460592eb7b243
- cache_divergence=DIFF
- json_keys: ["data","error","meta","metadata","ok","schema_version"]

### api_universe_debug_1
- default: http_code=200;time_total=0.395304;content_type=application/json; charset=utf-8;size_download=1090;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=200;time_total=0.585012;content_type=application/json; charset=utf-8;size_download=1090;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=6f252b7a064a350bf379ba1d65ae1b5ebfd5b66011adde34b38ef164874909fd
- hash_nocache=8bb3d228344c58908282653e716c427007ce9a23961d659f0a14cc2c8ba33faf
- cache_divergence=DIFF
- json_keys: ["asset_latency_ms","asset_status","build_id","config","data","data_preview","debug","error","failure","kv_backend","kv_latency_ms","kv_status","links","manifest","manifest_ref","meta","metadata","module","module_state","ok","proof_chain","proof_summary","schema_version","served_from","source","suggested_action","timestamp"]

### data_forecast_latest.json
- default: http_code=200;time_total=0.231432;content_type=application/json;size_download=209990;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=200;time_total=0.234039;content_type=application/json;size_download=209990;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=85659fdbe55ba9d4e243de33f9d7f05eba0893f3ccb02ce4397d00baed39b2d1
- hash_nocache=85659fdbe55ba9d4e243de33f9d7f05eba0893f3ccb02ce4397d00baed39b2d1
- cache_divergence=SAME
- json_keys: ["data","feature","generated_at","meta","ok","schema"]

### data_forecast_system_status.json
- default: http_code=200;time_total=0.180516;content_type=application/json;size_download=307;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=200;time_total=0.168966;content_type=application/json;size_download=307;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=4b1cb4227f0abccc5a73b89064aedbe945976f0f6986d1f8d20ec862d2984f3e
- hash_nocache=4b1cb4227f0abccc5a73b89064aedbe945976f0f6986d1f8d20ec862d2984f3e
- cache_divergence=SAME
- json_keys: ["capabilities","circuit_state","generated_at","last_good","last_run","reason","schema","status"]

### data_marketphase_index.json
- default: http_code=404;time_total=0.191348;content_type=text/html; charset=utf-8;size_download=1005;content_type_json=FAIL;html_prefix=FAIL;jq_parse=FAIL;body_non_empty=PASS;
- nocache: http_code=404;time_total=0.258014;content_type=text/html; charset=utf-8;size_download=1005;content_type_json=FAIL;html_prefix=FAIL;jq_parse=FAIL;body_non_empty=PASS;
- hash_default=9d05d6999e585a424c9d6ee7573542154e4f0b18228caeabf0f1fa7bc9be8c06
- hash_nocache=2c5107a7ab29a9345f5208cc63c6d345247e17e3810832b7b4f6b11047d28d48
- cache_divergence=DIFF
- json_keys: JSON_PARSE_FAILED

### data_snapshots_market-prices_latest.json
- default: http_code=200;time_total=0.288070;content_type=application/json;size_download=607501;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=200;time_total=0.323616;content_type=application/json;size_download=607501;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=2f6e9eaf9de92bf415d215ce9d0a202c474b9f59e76323e15c77e8a6e3cb2cb3
- hash_nocache=2f6e9eaf9de92bf415d215ce9d0a202c474b9f59e76323e15c77e8a6e3cb2cb3
- cache_divergence=SAME
- json_keys: ["data","error","meta","metadata","schema_version"]

### data_snapshots_stock-analysis.json
- default: http_code=200;time_total=0.448560;content_type=application/json;size_download=1219577;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=200;time_total=0.393102;content_type=application/json;size_download=1219577;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=567dc372579a350e0c273920375dacc17eb1dc7fe86bfbf635bf8f11e74170c0
- hash_nocache=567dc372579a350e0c273920375dacc17eb1dc7fe86bfbf635bf8f11e74170c0
- cache_divergence=SAME
- json_keys: ["A","AAPL","ABBV","ABNB","ABT","ACGL","ACN","ADBE","ADI","ADM","ADP","ADSK","AEE","AEP","AES","AFL","AIG","AIZ","AJG","AKAM","ALB","ALGN","ALL","ALLE","AMAT","AMCR","AMD","AME","AMGN","AMP","AMT","AMZN","ANET","AON","AOS","APA","APD","APH","APO","APP","APTV","ARE","ARM","ASML","ATO","AVB","AVGO","AVY","AWK","AXON","AXP","AZN","AZO","BA","BAC","BALL","BAX","BBY","BDX","BEN","BF.B","BG","BIIB","BK","BKNG","BKR","BLDR","BLK","BMY","BR","BRK.B","BRO","BSX","BX","BXP","C","CAG","CAH","CARR","CAT","CB","CBOE","CBRE","CCEP","CCI","CCL","CDNS","CDW","CEG","CF","CFG","CHD","CHRW","CHTR","CI","CINF","CL","CLX","CMCSA","CME","CMG","CMI","CMS","CNC","CNP","COF","COIN","COO","COP","COR","COST","CPAY","CPB","CPRT","CPT","CRL","CRM","CRWD","CSCO","CSGP","CSX","CTAS","CTRA","CTSH","CTVA","CVS","CVX","CZR","D","DAL","DASH","DAY","DD","DDOG","DE","DECK","DELL","DG","DGX","DHI","DHR","DIS","DLR","DLTR","DOC","DOV","DOW","DPZ","DRI","DTE","DUK","DVA","DVN","DXCM","EA","EBAY","ECL","ED","EFX","EG","EIX","EL","ELV","EMN","EMR","ENPH","EOG","EPAM","EQIX","EQR","EQT","ERIE","ES","ESS","ETN","ETR","EVRG","EW","EXC","EXE","EXPD","EXPE","EXR","F","FANG","FAST","FCX","FDS","FDX","FE","FFIV","FI","FICO","FIS","FITB","FOX","FOXA","FRT","FSLR","FTNT","FTV","GD","GDDY","GE","GEHC","GEN","GEV","GFS","GILD","GIS","GL","GLW","GM","GNRC","GOOG","GOOGL","GPC","GPN","GRMN","GS","GWW","HAL","HAS","HBAN","HCA","HD","HIG","HII","HLT","HOLX","HON","HPE","HPQ","HRL","HSIC","HST","HSY","HUBB","HUM","HWM","IBM","ICE","IDXX","IEX","IFF","INCY","INTC","INTU","INVH","IP","IPG","IQV","IR","IRM","ISRG","IT","ITW","IVZ","J","JBHT","JBL","JCI","JKHY","JNJ","JPM","K","KDP","KEY","KEYS","KHC","KIM","KKR","KLAC","KMB","KMI","KMX","KO","KR","KVUE","L","LDOS","LEN","LH","LHX","LII","LIN","LKQ","LLY","LMT","LNT","LOW","LRCX","LULU","LUV","LVS","LW","LYB","LYV","MA","MAA","MAR","MAS","MCD","MCHP","MCK","MCO","MDLZ","MDT","MELI","MET","META","MGM","MHK","MKC","MKTX","MLM","MMC","MMM","MNST","MO","MOH","MOS","MPC","MPWR","MRK","MRNA","MRVL","MS","MSCI","MSFT","MSI","MSTR","MTB","MTCH","MTD","MU","NCLH","NDAQ","NDSN","NEE","NEM","NFLX","NI","NKE","NOC","NOW","NRG","NSC","NTAP","NTRS","NUE","NVDA","NVR","NWS","NWSA","NXPI","O","ODFL","OKE","OMC","ON","ORCL","ORLY","OTIS","OXY","PANW","PAYC","PAYX","PCAR","PCG","PDD","PEG","PEP","PFE","PFG","PG","PGR","PH","PHM","PKG","PLD","PLTR","PM","PNC","PNR","PNW","PODD","POOL","PPG","PPL","PRU","PSA","PSKY","PSX","PTC","PWR","PYPL","QCOM","RCL","REG","REGN","RF","RJF","RL","RMD","ROK","ROL","ROP","ROST","RSG","RTX","RVTY","SBAC","SBUX","SCHW","SHOP","SHW","SJM","SLB","SMCI","SNA","SNPS","SO","SOLV","SPG","SPGI","SRE","STE","STLD","STT","STX","STZ","SW","SWK","SWKS","SYF","SYK","SYY","T","TAP","TDG","TDY","TEAM","TECH","TEL","TER","TFC","TGT","TJX","TKO","TMO","TMUS","TPL","TPR","TRGP","TRI","TRMB","TROW","TRV","TSCO","TSLA","TSN","TT","TTD","TTWO","TXN","TXT","TYL","UAL","UBER","UDR","UHS","ULTA","UNH","UNP","UPS","URI","USB","V","VICI","VLO","VLTO","VMC","VRSK","VRSN","VRTX","VST","VTR","VTRS","VZ","WAB","WAT","WBA","WBD","WDAY","WDC","WEC","WELL","WFC","WM","WMB","WMT","WRB","WSM","WST","WTW","WY","WYNN","XEL","XOM","XYL","XYZ","YUM","ZBH","ZBRA","ZS","ZTS","_meta","_rankings"]

### data_universe_all.json
- default: http_code=200;time_total=0.216413;content_type=application/json;size_download=30769;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- nocache: http_code=200;time_total=0.169941;content_type=application/json;size_download=30769;content_type_json=PASS;html_prefix=PASS;jq_parse=PASS;body_non_empty=PASS;
- hash_default=2672904ce07ec8bf26adcc87e654788c34f1aef79cca22a09d5cf14d3831252f
- hash_nocache=2672904ce07ec8bf26adcc87e654788c34f1aef79cca22a09d5cf14d3831252f
- cache_divergence=SAME
- json_keys: [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,266,267,268,269,270,271,272,273,274,275,276,277,278,279,280,281,282,283,284,285,286,287,288,289,290,291,292,293,294,295,296,297,298,299,300,301,302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,317,318,319,320,321,322,323,324,325,326,327,328,329,330,331,332,333,334,335,336,337,338,339,340,341,342,343,344,345,346,347,348,349,350,351,352,353,354,355,356,357,358,359,360,361,362,363,364,365,366,367,368,369,370,371,372,373,374,375,376,377,378,379,380,381,382,383,384,385,386,387,388,389,390,391,392,393,394,395,396,397,398,399,400,401,402,403,404,405,406,407,408,409,410,411,412,413,414,415,416,417,418,419,420,421,422,423,424,425,426,427,428,429,430,431,432,433,434,435,436,437,438,439,440,441,442,443,444,445,446,447,448,449,450,451,452,453,454,455,456,457,458,459,460,461,462,463,464,465,466,467,468,469,470,471,472,473,474,475,476,477,478,479,480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,495,496,497,498,499,500,501,502,503,504,505,506,507,508,509,510,511,512,513,514,515,516]

### html_
- html_probe_meta: http_code=200;time_total=0.217583;content_type=text/html; charset=utf-8;size_download=84862;html_markers=PASS;error_marker=NONE;

### html_elliott.html
- html_probe_meta: http_code=308;time_total=0.162210;content_type=;size_download=0;html_markers=FAIL;error_marker=NONE;

### html_forecast.html
- html_probe_meta: http_code=308;time_total=0.171198;content_type=;size_download=0;html_markers=FAIL;error_marker=NONE;

### html_scientific.html
- html_probe_meta: http_code=308;time_total=0.179980;content_type=;size_download=0;html_markers=FAIL;error_marker=NONE;

