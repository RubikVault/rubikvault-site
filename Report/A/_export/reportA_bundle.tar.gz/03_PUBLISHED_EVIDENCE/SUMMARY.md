# PUBLISHED SUMMARY

generated_at=2026-02-10T19:06:06+01:00

- inventory: 01_public_data_filelist.txt
- parse validation: 02_json_parse_validation.txt
- contracts: 03_critical_contracts.txt
- no-silent-shrink: 04_no_silent_shrink_checks.txt

# NO SILENT SHRINK CHECKS
universe_len=517
market_prices_len=517
forecast_len=517
market_prices_vs_universe=PASS
forecast_vs_universe=PASS
